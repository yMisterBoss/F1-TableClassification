import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';  // Importando as funcionalidades corretas
import DriverStandings from './components/DriverStandings';
import ConstructorsStandings from './components/ConstructorsStandings';
import RacesCalendar from './components/RacesCalendar';
import Navbar from './components/Navbar';
import './styles.css'; // Estilos globais

function App() {
  return (
    <Router>
      <div className="App">
        <Navbar />  {/* Adiciona a Navbar ao topo da página */}

        <Routes>
          {/* A rota principal agora usa o "element" para renderizar componentes */}
          <Route path="/" element={
            <>
              <h1>Classificação dos Pilotos</h1>
              <DriverStandings />
            </>
          } />

          <Route path="/constructors" element={
            <>
              <h1>Classificação dos Construtores</h1>
              <ConstructorsStandings />
            </>
          } />

          <Route path="/races" element={
            <>
              <h1>Calendário de Corridas</h1>
              <RacesCalendar />
            </>
          } />
        </Routes>
      </div>
    </Router>
  );
}

export default App;
