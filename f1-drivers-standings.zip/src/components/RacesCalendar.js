import React, { useEffect, useState } from 'react';
import axios from 'axios';

const RacesCalendar = () => {
  const [races, setRaces] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchRaces = async () => {
      try {
        const response = await axios.get('https://ergast.com/api/f1/current.json');
        const racesList = response.data.MRData.RaceTable.Races;
        setRaces(racesList);
        setLoading(false);
      } catch (error) {
        console.error("Erro ao buscar os dados:", error);
        setLoading(false);
      }
    };

    fetchRaces();
  }, []);

  if (loading) {
    return <p>A carregar calendário...</p>;
  }

  return (
    <div className="races">
      {races.map((race) => (
        <div key={race.date + race.time} className="race-card">
          <h2>{race.raceName}</h2>
          <p>Data: {new Date(race.date).toLocaleDateString()}</p>
          <p>Local: {race.Circuit.circuitName}</p>
        </div>
      ))}
    </div>
  );
};

export default RacesCalendar;
